import streamlit as st
import pandas as pd
import joblib
import os

# -----------------------------
# Debug Start
# -----------------------------
st.title("📞 Telecom Churn Predictor")

st.write("✅ App is running...")

# -----------------------------
# Load Model + Features
# -----------------------------
try:
    model = joblib.load("churn_model.pkl")
    feature_names = joblib.load("feature_names.pkl")
    st.success("✅ Model Loaded Successfully!")
except Exception as e:
    st.error("❌ Model loading failed!")
    st.write(e)
    st.stop()

# -----------------------------
# Inputs
# -----------------------------
st.header("Enter Customer Details")

total_complaints = st.number_input("Total Complaints", 0, 20, 1)
has_complaint = st.selectbox("Has Complaint?", [0, 1])

complaint_recency_days = st.number_input("Complaint Recency Days", 0, 1000, 999)

data_used_gb = st.number_input("Data Used (GB)", 0.0, 100.0, 5.0)
calls_made = st.number_input("Calls Made", 0, 500, 30)
revenue_inr = st.number_input("Revenue (INR)", 0, 10000, 200)

tenure = st.number_input("Tenure (Months)", 0, 100, 12)
monthly_charges = st.number_input("Monthly Charges", 0, 10000, 200)

region = st.selectbox("Region", ["Chandigarh", "Chennai", "Delhi", "Hyderabad", "Jaipur", "Kolkata", "Mumbai", "Pune"])
contract_type = st.selectbox("Contract Type", ["Month-to-Month", "One Year", "Two Year"])

# -----------------------------
# Predict Button
# -----------------------------
if st.button("Predict Churn"):

    # Create base input
    input_data = {
        "total_complaints": total_complaints,
        "has_complaint": has_complaint,
        "complaint_recency_days": complaint_recency_days,
        "data_used_gb": data_used_gb,
        "calls_made": calls_made,
        "revenue_inr": revenue_inr,
        "tenure": tenure,
        "monthly_charges": monthly_charges,
    }

    # Convert into DataFrame
    input_df = pd.DataFrame([input_data])

    # Manually add region dummy columns
    for r in ["Chandigarh", "Chennai", "Delhi", "Hyderabad", "Jaipur", "Kolkata", "Mumbai", "Pune"]:
        col = f"region_{r}"
        input_df[col] = 1 if region == r else 0

    # Manually add contract dummy columns
    for c in ["One Year", "Two Year"]:
        col = f"contract_type_{c}"
        input_df[col] = 1 if contract_type == c else 0

    # Add missing columns
    for col in feature_names:
        if col not in input_df.columns:
            input_df[col] = 0

    # Correct column order
    input_df = input_df[feature_names]

    # Predict probability
    prob = model.predict_proba(input_df)[0][1]

    st.subheader("Result")
    st.write(f"### Churn Probability: {prob:.2%}")

    if prob > 0.7:
        st.error("⚠️ High Risk Customer")
    elif prob > 0.4:
        st.warning("🟡 Medium Risk Customer")
    else:
        st.success("✅ Low Risk Customer")
